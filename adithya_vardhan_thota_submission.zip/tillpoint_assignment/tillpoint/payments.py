"""Payment provider webhooks. The provider retries a delivery until it gets a 2xx, so events can repeat."""
import sqlite3

from . import db
from .orders import Orders


class PaymentError(Exception):
    pass


class Payments:
    def __init__(self, conn, orders=None):
        self.conn = conn
        self.orders = orders or Orders(conn)

    def handle_event(self, event, now=None):
        """event: dict(id, type, order_id, amount_cents). Returns the order's status after the event."""
        if event.get("type") != "payment.succeeded":
            return None
        self.orders.expire_pending(now=now)
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            status = self._apply_succeeded(event, now)
            self.conn.execute("COMMIT")
            return status
        except sqlite3.IntegrityError:
            self._rollback_if_in_transaction()
            if self._event_recorded(event.get("id")):
                return self._status_for_event(event.get("id"))
            raise
        except Exception:
            self._rollback_if_in_transaction()
            raise

    def _apply_succeeded(self, event, now):
        if self._event_recorded(event["id"]):
            return self._status_for_event(event["id"])
        order = self.conn.execute("SELECT * FROM orders WHERE id = ?", (event["order_id"],)).fetchone()
        if order is None:
            raise PaymentError(f"payment for unknown order {event['order_id']}")
        if order["status"] in ("cancelled", "expired"):
            raise PaymentError(f"order {order['id']} is {order['status']}")
        remaining = order["total_cents"] - self.paid_cents(order["id"])
        amount = event["amount_cents"]
        if amount > remaining:
            raise PaymentError(
                f"payment of {amount} cents exceeds remaining balance {remaining} for order {order['id']}"
            )
        self.conn.execute(
            "INSERT INTO payments (order_id, event_id, amount_cents, received_at) VALUES (?, ?, ?, ?)",
            (order["id"], event["id"], amount, db.to_iso(now or db.utcnow())),
        )
        if order["status"] == "pending" and self.paid_cents(order["id"]) >= order["total_cents"]:
            self.conn.execute("UPDATE orders SET status = 'paid' WHERE id = ?", (order["id"],))
            return "paid"
        return order["status"]

    def _event_recorded(self, event_id):
        if event_id is None:
            return False
        row = self.conn.execute(
            "SELECT 1 FROM payments WHERE event_id = ?", (event_id,)
        ).fetchone()
        return row is not None

    def _status_for_event(self, event_id):
        """Current status of the order that already recorded this event_id, or None if unknown."""
        row = self.conn.execute(
            "SELECT order_id FROM payments WHERE event_id = ?", (event_id,)
        ).fetchone()
        if row is None:
            return None
        order = self.conn.execute("SELECT status FROM orders WHERE id = ?", (row["order_id"],)).fetchone()
        return None if order is None else order["status"]

    def _rollback_if_in_transaction(self):
        if not self.conn.in_transaction:
            return
        try:
            self.conn.execute("ROLLBACK")
        except Exception:
            pass

    def paid_cents(self, order_id):
        row = self.conn.execute(
            "SELECT COALESCE(SUM(amount_cents), 0) AS paid FROM payments WHERE order_id = ?", (order_id,)
        ).fetchone()
        return row["paid"]
