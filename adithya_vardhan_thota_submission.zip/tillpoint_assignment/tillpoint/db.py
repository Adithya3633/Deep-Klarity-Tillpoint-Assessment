"""SQLite storage. All money is integer cents; all timestamps are UTC ISO-8601 strings."""
import sqlite3
from datetime import datetime, timezone

SCHEMA = """
CREATE TABLE IF NOT EXISTS products (
    sku TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    price_cents INTEGER NOT NULL,
    stock INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS coupons (
    code TEXT PRIMARY KEY,
    kind TEXT NOT NULL CHECK (kind IN ('percent', 'fixed')),
    value INTEGER NOT NULL,
    min_subtotal_cents INTEGER NOT NULL DEFAULT 0,
    max_uses INTEGER,
    uses INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer TEXT NOT NULL,
    region TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    coupon TEXT,
    subtotal_cents INTEGER NOT NULL,
    discount_cents INTEGER NOT NULL DEFAULT 0,
    tax_cents INTEGER NOT NULL DEFAULT 0,
    total_cents INTEGER NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS order_items (
    order_id INTEGER NOT NULL REFERENCES orders(id),
    sku TEXT NOT NULL REFERENCES products(sku),
    qty INTEGER NOT NULL,
    unit_price_cents INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL REFERENCES orders(id),
    event_id TEXT NOT NULL,
    amount_cents INTEGER NOT NULL,
    received_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_payments_order ON payments(order_id);
CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer, created_at);
"""

# payments.event_id must be unique so a retried webhook cannot insert twice.
# CREATE TABLE IF NOT EXISTS will not add that rule to a database created before
# the index existed. connect() tries CREATE UNIQUE INDEX IF NOT EXISTS and does
# not delete or rewrite payment rows.
#
# If the file already has duplicate event_id values, index creation fails and
# the rows stay as they are. Open the file with a tool that is not this app,
# then migrate by hand:
#   1. SELECT event_id, COUNT(*) FROM payments GROUP BY event_id HAVING COUNT(*) > 1;
#   2. Copy every conflicting row into an archive table (all columns).
#   3. Compare the archive with the payment provider payout; retries of one
#      charge should keep one row per event_id (usually the earliest id).
#   4. After sign-off, DELETE from payments the extra ids that were archived.
#   5. CREATE UNIQUE INDEX idx_payments_event_id ON payments(event_id);
#   6. Re-check paid_cents vs order totals. Do not sum duplicate event_ids.


def connect(path=":memory:"):
    conn = sqlite3.connect(path, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(SCHEMA)
    _ensure_unique_payment_event_ids(conn)
    return conn


def _ensure_unique_payment_event_ids(conn):
    try:
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_payments_event_id ON payments(event_id)")
    except sqlite3.IntegrityError as e:
        raise sqlite3.IntegrityError(
            "cannot create unique index on payments.event_id because duplicate "
            "event_id values already exist; payment rows were not changed. "
            "Archive the extras, keep one row per event_id, then reconnect. "
            f"({e})"
        ) from e


def utcnow():
    return datetime.now(timezone.utc).replace(microsecond=0)


def to_iso(dt):
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def from_iso(text):
    return datetime.strptime(text, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
