"""Creating, cancelling and listing orders."""
from datetime import timedelta

from . import db, pricing
from .catalog import Catalog


PENDING_ORDER_TTL = timedelta(minutes=30)


class OrderError(Exception):
    pass


class Orders:
    def __init__(self, conn, catalog=None):
        self.conn = conn
        self.catalog = catalog or Catalog(conn)

    def create(self, customer, items, region="NONE", coupon_code=None, now=None):
        """items: list of (sku, qty). Reserves stock, redeems the coupon and stores the order, all or nothing."""
        if not items:
            raise OrderError("an order needs at least one item")
        if any(qty <= 0 for _, qty in items):
            raise OrderError("quantities must be positive")
        self.expire_pending(now=now)
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            coupon = self._coupon(coupon_code)
            priced = [(sku, qty, self.catalog.get_product(sku).price_cents) for sku, qty in items]
            totals = pricing.price_order([(price, qty) for _, qty, price in priced], region, coupon)
            for sku, qty, _ in priced:
                self.catalog.reserve(sku, qty)
            if coupon is not None:
                self.conn.execute("UPDATE coupons SET uses = uses + 1 WHERE code = ?", (coupon_code,))
            cur = self.conn.execute(
                "INSERT INTO orders (customer, region, coupon, subtotal_cents, discount_cents, tax_cents,"
                " total_cents, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (customer, region, coupon_code, totals["subtotal_cents"], totals["discount_cents"],
                 totals["tax_cents"], totals["total_cents"], db.to_iso(now or db.utcnow())),
            )
            order_id = cur.lastrowid
            self.conn.executemany(
                "INSERT INTO order_items (order_id, sku, qty, unit_price_cents) VALUES (?, ?, ?, ?)",
                [(order_id, sku, qty, price) for sku, qty, price in priced],
            )
            self.conn.execute("COMMIT")
        except Exception:
            self.conn.execute("ROLLBACK")
            raise
        return self.get(order_id)

    def cancel(self, order_id):
        """Cancel an order that has not shipped. Its stock and its coupon use go back."""
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            order = self.get(order_id)
            if order["status"] in ("cancelled", "expired"):
                self.conn.execute("COMMIT")
                return order
            if order["status"] == "shipped":
                raise OrderError("a shipped order cannot be cancelled")
            cur = self.conn.execute(
                "UPDATE orders SET status = 'cancelled' WHERE id = ? AND status IN ('pending', 'paid')",
                (order_id,),
            )
            if cur.rowcount:
                for item in order["items"]:
                    self.catalog.release(item["sku"], item["qty"])
            if order["coupon"]:
                self.conn.execute("UPDATE coupons SET uses = uses - 1 WHERE code = ? AND uses > 0", (order["coupon"],))
            self.conn.execute("COMMIT")
        except Exception:
            self.conn.execute("ROLLBACK")
            raise
        return self.get(order_id)

    def expire_pending(self, now=None):
        """Release reservations for unpaid checkouts older than the reservation window."""
        cutoff = db.to_iso((now or db.utcnow()) - PENDING_ORDER_TTL)
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            orders = self.conn.execute(
                "SELECT id, coupon FROM orders o WHERE status = 'pending' AND created_at <= ?"
                " AND NOT EXISTS (SELECT 1 FROM payments p WHERE p.order_id = o.id)",
                (cutoff,),
            ).fetchall()
            expired = 0
            for order in orders:
                cur = self.conn.execute(
                    "UPDATE orders SET status = 'expired' WHERE id = ? AND status = 'pending'"
                    " AND NOT EXISTS (SELECT 1 FROM payments p WHERE p.order_id = orders.id)",
                    (order["id"],),
                )
                if cur.rowcount == 0:
                    continue
                items = self.conn.execute(
                    "SELECT sku, qty FROM order_items WHERE order_id = ?", (order["id"],)
                ).fetchall()
                for item in items:
                    self.catalog.release(item["sku"], item["qty"])
                if order["coupon"]:
                    self.conn.execute(
                        "UPDATE coupons SET uses = uses - 1 WHERE code = ? AND uses > 0",
                        (order["coupon"],),
                    )
                expired += 1
            self.conn.execute("COMMIT")
            return expired
        except Exception:
            self.conn.execute("ROLLBACK")
            raise

    def ship(self, order_id):
        order = self.get(order_id)
        if order["status"] != "paid":
            raise OrderError("only a paid order can ship")
        self.conn.execute("UPDATE orders SET status = 'shipped' WHERE id = ?", (order_id,))
        return self.get(order_id)

    def get(self, order_id):
        row = self.conn.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
        if row is None:
            raise OrderError(f"no order {order_id}")
        order = dict(row)
        order["items"] = [dict(r) for r in self.conn.execute(
            "SELECT sku, qty, unit_price_cents FROM order_items WHERE order_id = ? ORDER BY rowid", (order_id,))]
        return order

    def list_for(self, customer, page=1, per_page=20):
        rows = self.conn.execute(
            "SELECT id FROM orders WHERE customer = ? ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?",
            (customer, per_page, (page - 1) * per_page),
        ).fetchall()
        return [self.get(r["id"]) for r in rows]

    def _coupon(self, code):
        if code is None:
            return None
        row = self.conn.execute("SELECT * FROM coupons WHERE code = ?", (code,)).fetchone()
        if row is None:
            raise pricing.CouponRejected(f"unknown coupon {code}")
        return row
