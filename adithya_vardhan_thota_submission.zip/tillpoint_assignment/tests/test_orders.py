import os
import sqlite3
import tempfile
import threading
import unittest
from datetime import datetime, timezone
from unittest.mock import patch

from tillpoint import db, pricing, reports
from tillpoint.api import App
from tillpoint.catalog import OutOfStock
from tillpoint.payments import PaymentError


class OrderDeskTest(unittest.TestCase):
    def setUp(self):
        self.conn = db.connect()
        self.app = App(self.conn)
        self.app.catalog.add_product("MUG", "Mug", 1200, stock=10)
        self.app.catalog.add_product("TEE", "T-shirt", 2500, stock=3)
        self.conn.execute("INSERT INTO coupons (code, kind, value) VALUES ('TEN', 'percent', 10)")

    def test_order_totals_with_tax(self):
        order = self.app.orders.create("ana", [("MUG", 2), ("TEE", 1)], region="CA")
        self.assertEqual(order["subtotal_cents"], 4900)
        self.assertEqual(order["tax_cents"], 355)
        self.assertEqual(order["total_cents"], 5255)
        self.assertEqual(self.app.catalog.get_product("MUG").stock, 8)

    def test_coupon_takes_ten_percent(self):
        order = self.app.orders.create("ana", [("MUG", 1)], coupon_code="TEN")
        self.assertEqual(order["discount_cents"], 120)
        self.assertEqual(order["total_cents"], 1080)

    def test_percentage_coupon_tax_is_calculated_after_discount(self):
        order = self.app.orders.create("ana", [("MUG", 1)], region="CA", coupon_code="TEN")
        self.assertEqual(order["subtotal_cents"], 1200)
        self.assertEqual(order["discount_cents"], 120)
        self.assertEqual(order["tax_cents"], 78)
        self.assertEqual(order["total_cents"], 1158)

    def test_fixed_coupon_tax_is_calculated_after_discount(self):
        self.conn.execute(
            "INSERT INTO coupons (code, kind, value) VALUES ('FIVE', 'fixed', 500)"
        )
        order = self.app.orders.create("ana", [("MUG", 1)], region="CA", coupon_code="FIVE")
        self.assertEqual(order["subtotal_cents"], 1200)
        self.assertEqual(order["discount_cents"], 500)
        self.assertEqual(order["tax_cents"], 51)
        self.assertEqual(order["total_cents"], 751)

    def test_no_coupon_tax_behavior_is_unchanged(self):
        order = self.app.orders.create("ana", [("MUG", 1)], region="CA")
        self.assertEqual(order["discount_cents"], 0)
        self.assertEqual(order["tax_cents"], 87)
        self.assertEqual(order["total_cents"], 1287)

    def test_rounding_and_fixed_discount_capped_at_subtotal(self):
        half_cent_coupon = {
            "code": "HALF",
            "kind": "percent",
            "value": 50,
            "min_subtotal_cents": 0,
            "max_uses": None,
            "uses": 0,
        }
        rounded = pricing.price_order([(1, 1)], "CA", half_cent_coupon)
        self.assertEqual(rounded["discount_cents"], 1)
        self.assertEqual(rounded["tax_cents"], 0)
        self.assertEqual(rounded["total_cents"], 0)

        self.conn.execute(
            "INSERT INTO coupons (code, kind, value) VALUES ('OVER', 'fixed', 2000)"
        )
        order = self.app.orders.create("ana", [("MUG", 1)], region="CA", coupon_code="OVER")
        self.assertEqual(order["discount_cents"], 1200)
        self.assertEqual(order["tax_cents"], 0)
        self.assertEqual(order["total_cents"], 0)

    def test_coupon_minimum_subtotal_is_preserved(self):
        self.conn.execute(
            "INSERT INTO coupons (code, kind, value, min_subtotal_cents)"
            " VALUES ('MINIMUM', 'fixed', 100, 2000)"
        )
        with self.assertRaises(pricing.CouponRejected):
            self.app.orders.create("ana", [("MUG", 1)], region="CA", coupon_code="MINIMUM")

    def test_out_of_stock(self):
        with self.assertRaises(OutOfStock):
            self.app.orders.create("ana", [("TEE", 4)])
        self.assertEqual(self.app.catalog.get_product("TEE").stock, 3)

    def test_failed_reservation_rolls_back_earlier_items(self):
        with self.assertRaises(OutOfStock):
            self.app.orders.create("ana", [("MUG", 1), ("TEE", 4)])
        self.assertEqual(self.app.catalog.get_product("MUG").stock, 10)
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM orders").fetchone()[0], 0)

    def test_concurrent_orders_do_not_oversell_cached_stock(self):
        with tempfile.TemporaryDirectory() as directory:
            path = os.path.join(directory, "orders.sqlite")
            seed = db.connect(path)
            seed.execute(
                "INSERT INTO products (sku, name, price_cents, stock) VALUES ('LAST', 'Last', 100, 1)"
            )
            seed.close()

            start = threading.Barrier(2)
            outcomes = []
            outcomes_lock = threading.Lock()

            def create_order(customer):
                conn = db.connect(path)
                try:
                    app = App(conn)
                    self.assertEqual(app.catalog.get_product("LAST").stock, 1)
                    start.wait(timeout=5)
                    outcome = app.handle("POST", "/orders", {
                        "customer": customer,
                        "items": [{"sku": "LAST", "qty": 1}],
                    })
                except Exception as error:
                    outcome = error
                finally:
                    conn.close()
                with outcomes_lock:
                    outcomes.append(outcome)

            workers = [
                threading.Thread(target=create_order, args=(f"worker-{index}",))
                for index in range(2)
            ]
            for worker in workers:
                worker.start()
            for worker in workers:
                worker.join(timeout=10)

            self.assertFalse(any(worker.is_alive() for worker in workers))
            self.assertEqual(len(outcomes), 2)
            self.assertTrue(all(isinstance(outcome, tuple) for outcome in outcomes), outcomes)
            self.assertEqual(sorted(status for status, _ in outcomes), [201, 409])
            conflict = next(payload for status, payload in outcomes if status == 409)
            self.assertIn("0 available", conflict["error"])

            check = db.connect(path)
            try:
                self.assertEqual(check.execute(
                    "SELECT stock FROM products WHERE sku = 'LAST'"
                ).fetchone()["stock"], 0)
                self.assertEqual(check.execute("SELECT COUNT(*) FROM orders").fetchone()[0], 1)
            finally:
                check.close()

    def test_payment_marks_order_paid(self):
        order = self.app.orders.create("ana", [("MUG", 1)])
        status, payload = self.app.handle("POST", "/webhooks/payments", {
            "id": "evt_1", "type": "payment.succeeded", "order_id": order["id"], "amount_cents": 1200})
        self.assertEqual((status, payload["status"]), (200, "paid"))

    def test_cancel_paid_order_restocks(self):
        order = self.app.orders.create("ana", [("TEE", 2)])
        self.app.payments.handle_event(
            {"id": "evt_2", "type": "payment.succeeded", "order_id": order["id"], "amount_cents": 5000})
        self.app.orders.cancel(order["id"])
        self.assertEqual(self.app.catalog.get_product("TEE").stock, 3)

    def test_cancel_pending_order_restocks_only_once(self):
        order = self.app.orders.create("ana", [("MUG", 2)])
        self.assertEqual(self.app.catalog.get_product("MUG").stock, 8)

        self.app.orders.cancel(order["id"])
        self.assertEqual(self.app.catalog.get_product("MUG").stock, 10)

        self.app.orders.cancel(order["id"])
        self.assertEqual(self.app.catalog.get_product("MUG").stock, 10)

    def test_abandoned_order_expires_on_stock_read(self):
        created = datetime(2025, 3, 10, 12, 0, tzinfo=timezone.utc)
        expired_at = datetime(2025, 3, 10, 12, 31, tzinfo=timezone.utc)
        order = self.app.orders.create("ana", [("MUG", 2)], coupon_code="TEN", now=created)

        with patch("tillpoint.orders.db.utcnow", return_value=expired_at):
            status, product = self.app.handle("GET", "/products/MUG")

        self.assertEqual(status, 200)
        self.assertEqual(product["stock"], 10)
        self.assertEqual(self.app.orders.get(order["id"])["status"], "expired")
        self.assertEqual(self.conn.execute("SELECT uses FROM coupons WHERE code = 'TEN'").fetchone()["uses"], 0)
        self.app.orders.cancel(order["id"])
        self.assertEqual(self.app.catalog.get_product("MUG").stock, 10)

    def test_checkout_expires_abandoned_reservation_before_reserving(self):
        created = datetime(2025, 3, 10, 12, 0, tzinfo=timezone.utc)
        expired_at = datetime(2025, 3, 10, 12, 31, tzinfo=timezone.utc)
        abandoned = self.app.orders.create("ana", [("TEE", 3)], now=created)

        order = self.app.orders.create("bo", [("TEE", 1)], now=expired_at)

        self.assertEqual(self.app.orders.get(abandoned["id"])["status"], "expired")
        self.assertEqual(self.app.catalog.get_product("TEE").stock, 2)
        self.assertEqual(order["status"], "pending")

    def test_partial_payment_prevents_checkout_expiry(self):
        created = datetime(2025, 3, 10, 12, 0, tzinfo=timezone.utc)
        expired_at = datetime(2025, 3, 10, 12, 31, tzinfo=timezone.utc)
        order = self.app.orders.create("ana", [("MUG", 1)], now=created)
        self.app.payments.handle_event(
            {
                "id": "evt_partial_expiry",
                "type": "payment.succeeded",
                "order_id": order["id"],
                "amount_cents": 500,
            },
            now=created,
        )

        with patch("tillpoint.orders.db.utcnow", return_value=expired_at):
            self.app.handle("GET", "/products/MUG")

        self.assertEqual(self.app.orders.get(order["id"])["status"], "pending")
        self.assertEqual(self.app.catalog.get_product("MUG").stock, 9)

    def test_payment_after_expiry_is_rejected(self):
        created = datetime(2025, 3, 10, 12, 0, tzinfo=timezone.utc)
        expired_at = datetime(2025, 3, 10, 12, 31, tzinfo=timezone.utc)
        order = self.app.orders.create("ana", [("MUG", 1)], now=created)

        with patch("tillpoint.orders.db.utcnow", return_value=expired_at):
            self.app.handle("GET", "/products/MUG")
            with self.assertRaises(PaymentError):
                self.app.payments.handle_event({
                    "id": "evt_expired_order",
                    "type": "payment.succeeded",
                    "order_id": order["id"],
                    "amount_cents": 1200,
                })

        self.assertEqual(self.app.orders.get(order["id"])["status"], "expired")
        self.assertEqual(self.app.payments.paid_cents(order["id"]), 0)
        self.assertEqual(self.app.catalog.get_product("MUG").stock, 10)

    def test_daily_sales(self):
        order = self.app.orders.create("ana", [("MUG", 1)])
        noon = datetime(2025, 3, 10, 12, 0, tzinfo=timezone.utc)
        self.app.payments.handle_event(
            {"id": "evt_3", "type": "payment.succeeded", "order_id": order["id"], "amount_cents": 1200}, now=noon)
        self.assertEqual(reports.daily_sales(self.conn, "2025-03-10"),
                         {"day": "2025-03-10", "revenue_cents": 1200, "orders": 1})

    def test_daily_sales_uses_india_local_day_boundaries(self):
        sales = [
            ("2025-03-09T18:29:59Z", 10),
            ("2025-03-09T18:30:00Z", 100),
            ("2025-03-09T20:00:00Z", 200),
            ("2025-03-10T18:29:59Z", 300),
            ("2025-03-10T18:30:00Z", 400),
        ]
        for index, (timestamp, amount) in enumerate(sales):
            order = self.app.orders.create("ana", [("MUG", 1)])
            self.app.payments.handle_event(
                {
                    "id": f"evt_india_{index}",
                    "type": "payment.succeeded",
                    "order_id": order["id"],
                    "amount_cents": amount,
                },
                now=db.from_iso(timestamp),
            )

        self.assertEqual(
            reports.daily_sales(self.conn, "2025-03-09"),
            {"day": "2025-03-09", "revenue_cents": 10, "orders": 1},
        )
        self.assertEqual(
            reports.daily_sales(self.conn, "2025-03-10"),
            {"day": "2025-03-10", "revenue_cents": 600, "orders": 3},
        )
        self.assertEqual(
            reports.daily_sales(self.conn, "2025-03-11"),
            {"day": "2025-03-11", "revenue_cents": 400, "orders": 1},
        )
        self.assertEqual(
            reports.daily_sales(self.conn, "2025-03-10", utc_offset_minutes=330),
            {"day": "2025-03-10", "revenue_cents": 600, "orders": 3},
        )
        status, payload = self.app.handle("GET", "/reports/daily/2025-03-10")
        self.assertEqual((status, payload), (200, {
            "day": "2025-03-10", "revenue_cents": 600, "orders": 3,
        }))

    def test_price_change(self):
        self.app.handle("PUT", "/products/MUG", {"price_cents": 1500})
        self.assertEqual(self.app.catalog.get_product("MUG").price_cents, 1500)

    def test_duplicate_payment_event_is_recorded_once(self):
        order = self.app.orders.create("ana", [("MUG", 1)])
        noon = datetime(2025, 3, 10, 12, 0, tzinfo=timezone.utc)
        event = {
            "id": "evt_dup",
            "type": "payment.succeeded",
            "order_id": order["id"],
            "amount_cents": 1200,
        }
        first = self.app.payments.handle_event(event, now=noon)
        second = self.app.payments.handle_event(event, now=noon)
        self.assertEqual(first, "paid")
        self.assertEqual(second, "paid")
        rows = self.conn.execute(
            "SELECT event_id, amount_cents FROM payments WHERE order_id = ?", (order["id"],)
        ).fetchall()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["event_id"], "evt_dup")
        self.assertEqual(self.app.payments.paid_cents(order["id"]), order["total_cents"])
        self.assertEqual(
            reports.daily_sales(self.conn, "2025-03-10"),
            {"day": "2025-03-10", "revenue_cents": 1200, "orders": 1},
        )

    def test_payment_amount_greater_than_order_total_does_not_inflate_received(self):
        order = self.app.orders.create("ana", [("MUG", 1)])
        noon = datetime(2025, 3, 10, 12, 0, tzinfo=timezone.utc)
        with self.assertRaises(PaymentError):
            self.app.payments.handle_event(
                {
                    "id": "evt_over",
                    "type": "payment.succeeded",
                    "order_id": order["id"],
                    "amount_cents": 5000,
                },
                now=noon,
            )
        self.assertEqual(self.app.orders.get(order["id"])["status"], "pending")
        self.assertEqual(self.app.payments.paid_cents(order["id"]), 0)
        self.assertEqual(
            len(self.conn.execute(
                "SELECT id FROM payments WHERE order_id = ?", (order["id"],)
            ).fetchall()),
            0,
        )
        self.assertEqual(
            reports.daily_sales(self.conn, "2025-03-10"),
            {"day": "2025-03-10", "revenue_cents": 0, "orders": 0},
        )

    def test_second_full_payment_with_different_event_id_is_rejected(self):
        order = self.app.orders.create("ana", [("MUG", 1)])
        first_event = {
            "id": "evt_full_first",
            "type": "payment.succeeded",
            "order_id": order["id"],
            "amount_cents": order["total_cents"],
        }
        second_event = {
            "id": "evt_full_second",
            "type": "payment.succeeded",
            "order_id": order["id"],
            "amount_cents": order["total_cents"],
        }

        self.assertEqual(
            self.app.handle("POST", "/webhooks/payments", first_event),
            (200, {"status": "paid"}),
        )
        status, payload = self.app.handle("POST", "/webhooks/payments", second_event)

        self.assertEqual(status, 409)
        self.assertIn("exceeds remaining balance 0", payload["error"])
        self.assertEqual(self.app.orders.get(order["id"])["status"], "paid")
        self.assertEqual(self.app.payments.paid_cents(order["id"]), order["total_cents"])
        rows = self.conn.execute(
            "SELECT event_id, amount_cents FROM payments WHERE order_id = ?", (order["id"],)
        ).fetchall()
        self.assertEqual([dict(row) for row in rows], [{
            "event_id": "evt_full_first",
            "amount_cents": order["total_cents"],
        }])

    def test_partial_payment_below_remaining_balance_is_accepted(self):
        order = self.app.orders.create("ana", [("MUG", 1)])
        noon = datetime(2025, 3, 10, 12, 0, tzinfo=timezone.utc)
        status = self.app.payments.handle_event(
            {
                "id": "evt_part_1",
                "type": "payment.succeeded",
                "order_id": order["id"],
                "amount_cents": 500,
            },
            now=noon,
        )
        self.assertEqual(status, "pending")
        self.assertEqual(self.app.payments.paid_cents(order["id"]), 500)
        with self.assertRaises(PaymentError):
            self.app.payments.handle_event(
                {
                    "id": "evt_part_over",
                    "type": "payment.succeeded",
                    "order_id": order["id"],
                    "amount_cents": 701,
                },
                now=noon,
            )
        self.assertEqual(self.app.payments.paid_cents(order["id"]), 500)
        status = self.app.payments.handle_event(
            {
                "id": "evt_part_2",
                "type": "payment.succeeded",
                "order_id": order["id"],
                "amount_cents": 700,
            },
            now=noon,
        )
        self.assertEqual(status, "paid")
        self.assertEqual(self.app.payments.paid_cents(order["id"]), order["total_cents"])

    def test_duplicate_webhook_after_order_cancelled_is_noop(self):
        order = self.app.orders.create("ana", [("MUG", 1)])
        event = {
            "id": "evt_then_cancel",
            "type": "payment.succeeded",
            "order_id": order["id"],
            "amount_cents": 1200,
        }
        self.assertEqual(self.app.payments.handle_event(event), "paid")
        self.app.orders.cancel(order["id"])
        retry = self.app.payments.handle_event(event)
        self.assertEqual(retry, "cancelled")
        self.assertEqual(
            len(self.conn.execute(
                "SELECT id FROM payments WHERE event_id = ?", ("evt_then_cancel",)
            ).fetchall()),
            1,
        )

    def test_same_event_id_different_order_id_is_noop_for_original_order(self):
        first = self.app.orders.create("ana", [("MUG", 1)])
        second = self.app.orders.create("ana", [("TEE", 1)])
        self.app.payments.handle_event({
            "id": "evt_shared",
            "type": "payment.succeeded",
            "order_id": first["id"],
            "amount_cents": 1200,
        })
        status = self.app.payments.handle_event({
            "id": "evt_shared",
            "type": "payment.succeeded",
            "order_id": second["id"],
            "amount_cents": 2500,
        })
        self.assertEqual(status, "paid")
        self.assertEqual(self.app.payments.paid_cents(first["id"]), 1200)
        self.assertEqual(self.app.payments.paid_cents(second["id"]), 0)
        self.assertEqual(self.app.orders.get(second["id"])["status"], "pending")
        rows = self.conn.execute(
            "SELECT order_id, amount_cents FROM payments WHERE event_id = ?", ("evt_shared",)
        ).fetchall()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["order_id"], first["id"])
        self.assertEqual(rows[0]["amount_cents"], 1200)

    def test_same_event_id_different_amount_keeps_original_amount(self):
        order = self.app.orders.create("ana", [("MUG", 1)])
        self.app.payments.handle_event({
            "id": "evt_amt",
            "type": "payment.succeeded",
            "order_id": order["id"],
            "amount_cents": 1200,
        })
        status = self.app.payments.handle_event({
            "id": "evt_amt",
            "type": "payment.succeeded",
            "order_id": order["id"],
            "amount_cents": 5000,
        })
        self.assertEqual(status, "paid")
        row = self.conn.execute(
            "SELECT amount_cents FROM payments WHERE event_id = ?", ("evt_amt",)
        ).fetchone()
        self.assertEqual(row["amount_cents"], 1200)
        self.assertEqual(self.app.payments.paid_cents(order["id"]), 1200)

    def test_different_event_ids_for_same_order_are_separate_payments(self):
        order = self.app.orders.create("ana", [("MUG", 1)])
        first = self.app.payments.handle_event({
            "id": "evt_a",
            "type": "payment.succeeded",
            "order_id": order["id"],
            "amount_cents": 500,
        })
        second = self.app.payments.handle_event({
            "id": "evt_b",
            "type": "payment.succeeded",
            "order_id": order["id"],
            "amount_cents": 700,
        })
        self.assertEqual(first, "pending")
        self.assertEqual(second, "paid")
        event_ids = [r["event_id"] for r in self.conn.execute(
            "SELECT event_id FROM payments WHERE order_id = ? ORDER BY event_id", (order["id"],)
        ).fetchall()]
        self.assertEqual(event_ids, ["evt_a", "evt_b"])
        self.assertEqual(self.app.payments.paid_cents(order["id"]), 1200)

    def test_unrelated_integrity_error_is_reraised(self):
        order = self.app.orders.create("ana", [("MUG", 1)])
        err = sqlite3.IntegrityError("FOREIGN KEY constraint failed")
        with patch.object(self.app.payments, "_apply_succeeded", side_effect=err):
            with self.assertRaises(sqlite3.IntegrityError) as raised:
                self.app.payments.handle_event({
                    "id": "evt_fk",
                    "type": "payment.succeeded",
                    "order_id": order["id"],
                    "amount_cents": 1200,
                })
        self.assertIs(raised.exception, err)
        self.assertEqual(self.app.payments.paid_cents(order["id"]), 0)
        self.assertFalse(self.conn.in_transaction)


if __name__ == "__main__":
    unittest.main()
