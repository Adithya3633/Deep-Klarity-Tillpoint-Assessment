### Report 1: Payment revenue higher than provider payout

**Root cause**

The payment webhook handler inserted a new payment record for every successful webhook delivery without checking whether the same event ID had already been processed. Since payment providers can retry webhook deliveries, the same payment could be recorded multiple times.

The handler also did not validate the received amount against the remaining order balance. This allowed an order's recorded payments and daily revenue to exceed its total.

**Reproduction**

Created an order with a total of 1200 cents and sent the same successful payment event twice using the same event ID.

Before the fix, both deliveries inserted payment records, resulting in 2400 cents of recorded payments for a 1200-cent order.

A separate test sent a 5000-cent payment for a 1200-cent order and demonstrated that the original implementation accepted the excessive amount.

**Fix implemented**

- Added a unique database index on `payments.event_id`.
- Added an idempotency check before validating the incoming order or amount. Previously processed events return the original order's current status without inserting another payment.
- Used `BEGIN IMMEDIATE` to serialize concurrent webhook writers using the same SQLite database.
- Treated an integrity error as a duplicate only when the corresponding event ID already exists. Unrelated integrity errors are re-raised.
- Added validation to reject payments exceeding the remaining order balance.
- Preserved valid partial payments.
- Added safe rollback handling.
- Existing databases containing duplicate event IDs are not automatically modified. Index creation fails, and an explicit, auditable reconciliation and migration is required.

**Tests added**

- Duplicate payment event is recorded only once.
- Overpayment is rejected without storing the payment.
- Valid partial payment is accepted.
- Duplicate delivery after order cancellation.
- Same event ID with a different order ID.
- Same event ID with a different amount.
- Different event IDs for the same order.
- Unrelated integrity errors are re-raised.

**Test results**

All 15 tests passed, including the original seven tests.

Command executed:

`python -m unittest discover -s tests -v`

Result: `Ran 15 tests ... OK`

**Design decisions and trade-offs**

Event ID uniqueness handles webhook retries, while the remaining-balance validation prevents an individual order from receiving more than its outstanding balance through this payment flow.

Two different event IDs are treated as separate payment events rather than duplicate deliveries. A separate business policy is required for genuine additional successful charges, as described in Report 6.

The unique index protects against duplicate event IDs at the database level. `BEGIN IMMEDIATE` serializes webhook writers using the same SQLite database file. This is not a general distributed locking mechanism.

Existing duplicate payment records require explicit reconciliation with provider records before cleanup. No financial records are automatically deleted or rewritten.

### Report 2: Products appear sold out after abandoned checkouts

**Status:** Fixed; no commit created yet, as requested.

**Reproduction**

With 2 units in stock, created two unpaid one-unit orders. Stock fell to 0. Cancelling one pending order left stock at 0, and a third checkout raised `OutOfStock`, even though the cancelled order was no longer active. The new tests reproduced both this cancellation leak and the indefinite reservation for abandoned orders.

Before the fix, the five focused Report 2 tests ran with 3 failures, 1 error and 1 pass. The pending-cancel test failed because stock stayed at 8 instead of returning to 10; the stock-read expiry test stayed at 8; a new checkout errored with `OutOfStock`; and a payment after expiry was incorrectly accepted. The partial-payment policy test passed because the original implementation did not expire any orders.

**Inventory flow and root cause**

- `Catalog.add_product()` inserts the initial stock. `Catalog.get_product()` reads a cached product or loads it from SQLite.
- `Orders.create()` calls `Catalog.reserve()` before inserting the order. The order starts `pending`; reserving decrements the product row immediately.
- A successful payment changes a fully paid order to `paid`; stock is not decremented again.
- `Orders.cancel()` previously restored stock only for `paid` orders, so cancelling a `pending` checkout leaked its reservation. An abandoned `pending` order had no expiry path and retained its reservation indefinitely.
- Stock reads use `Catalog.get_product()` through `GET /products/<sku>`. `add_product`, `update_price`, `reserve`, and `release` invalidate that Catalog instance's cache. The repro is present in SQLite stock itself, so cache invalidation is not its cause. The cache is process-local, however, so separate workers can still observe stale stock after another worker changes it; that is a separate consistency risk.

**Fix and policy**

- Cancellation now transitions pending or paid orders under `BEGIN IMMEDIATE` and restores their stock. Repeated cancellation, and cancellation of an already expired order, is a no-op; the status transition and stock update share a transaction to prevent a second release.
- Zero-payment pending orders expire after 30 minutes. The lazy expiry sweep runs before checkout, product-stock reads, order reads, and successful-payment handling. Expiry marks the order `expired`, restores each item and the coupon use, and is transactional.
- Orders with any successful partial payment are deliberately not expired; they keep their reservation until paid or explicitly cancelled. Payment events for expired orders are rejected. There is no refund integration, so any provider charge that arrives after expiry needs manual reconciliation/refund.
- No scheduler exists in this application, so expiry is lazy: due orders are released at the next relevant request rather than at the exact 30-minute mark. This keeps the change small and dependency-free, but stock cleanup is not an autonomous background task. Partially paid orders can therefore continue reserving stock indefinitely under the selected policy.

**Tests and verification**

- Added tests for pending-order cancellation and exactly-once release, expiry on stock read, expiry before a new reservation, partial-payment exemption, and rejection of payment after expiry (including coupon restoration).
- Focused Report 2 tests after the fix: 5 passed.
- Full suite: `python -m unittest discover -s tests -v` — 20 tests passed.
- `git diff --check` completed without whitespace errors. Final diff review confirmed only Report 2 implementation, tests, and this section of `NOTES.md` changed; Report 1 files were not edited.

**Commit**

Not committed, per instruction. Proposed commit message: `Fix abandoned checkout stock reservations`

### Report 3: Coupon orders are taxed on too much

**Status:** Fixed; no commit created yet, as requested.

**Reproduction**

For a 1200-cent mug in CA, the no-coupon order is subtotal 1200 cents, tax 87 cents, and total 1287 cents. The same order with the 10-percent `TEN` coupon was 1200 cents subtotal, 120 cents discount, but 87 cents tax and 1167 cents total. It should tax the post-discount 1080-cent amount, producing 78 cents tax and a 1158-cent total.

The same defect reproduced with a 500-cent fixed coupon: tax remained 87 cents instead of 51 cents on the 700-cent taxable amount, and the total remained 787 cents instead of 751 cents.

**Pricing flow and root cause**

- `Catalog.get_product().price_cents` supplies each unit price.
- `Orders.create()` builds `(unit_price_cents, qty)` lines and calls `pricing.price_order()`.
- `pricing.subtotal()` calculates the pre-coupon item subtotal.
- `pricing.discount_for()` validates the coupon minimum subtotal and use limit, calculates percentage or fixed-amount discount, and caps it at the subtotal.
- `pricing.tax_for()` applies the region tax basis points and half-up rounds the result.
- `Orders.create()` stores the returned subtotal, discount, tax, and total in the order row.
- Receipt/API order payload and payment balance consume `orders.total_cents`; the daily report and payment flow use the recorded payment amount rather than recalculating tax.

The exact root cause was in `tillpoint/pricing.py`: `price_order()` called `tax_for(sub, region)` before calling `discount_for()` and before calculating the post-discount taxable amount. Therefore every coupon in a taxed region had tax calculated from the full subtotal. Orders without coupons were coincidentally correct because their discount is zero.

**Policy and fix**

The project brief and README do not explicitly state tax policy. I stopped before implementation and confirmed the intended choice: tax must be calculated from the post-discount subtotal. The fix calculates the discount first, derives `taxable = max(subtotal - discount, 0)`, and passes that amount to `tax_for()`.

This is the smallest correction and is contained in `tillpoint/pricing.py`. Coupon validation, percentage/fixed discount calculations, existing half-up rounding, minimum subtotal checks, use limits, and the 0-discount no-coupon path were not reworked. Capping the taxable amount at zero is defensive; `discount_for()` already caps discounts at the subtotal.

**Tests and verification**

Added Report 3 regressions to `tests/test_orders.py` for:
- a 10-percent coupon in CA,
- a 500-cent fixed coupon in CA,
- unchanged no-coupon CA tax,
- half-cent/rounding behavior,
- a fixed discount exceeding the subtotal,
- preservation of minimum-subtotal coupon rejection.

Before the fix, three focused coupon/cap regressions failed while the no-coupon and minimum-subtotal checks passed. After the fix, all five focused Report 3 tests passed:

`python -m unittest -v tests.test_orders.OrderDeskTest.test_percentage_coupon_tax_is_calculated_after_discount tests.test_orders.OrderDeskTest.test_fixed_coupon_tax_is_calculated_after_discount tests.test_orders.OrderDeskTest.test_no_coupon_tax_behavior_is_unchanged tests.test_orders.OrderDeskTest.test_rounding_and_fixed_discount_capped_at_subtotal tests.test_orders.OrderDeskTest.test_coupon_minimum_subtotal_is_preserved`

The complete suite passed with 25 tests:

`python -m unittest discover -s tests -v`

Result: `Ran 25 tests ... OK`

`git diff --check` completed without whitespace errors.

**Trade-offs**

The change applies the same post-discount rule to every taxed region and both coupon kinds. It does not change untaxed regions or no-coupon totals. Percentage discounts are still rounded before tax; the post-discount amount and tax remain integer cents using the project's existing half-up helpers. Coupon use limits and minimum subtotal behavior remain unchanged.

**Commit**

Not committed, per instruction.

Proposed commit message: `Fix tax calculation for coupon orders`

### Development commands and verification

Environment:
- Python 3.11.9

Initial repository verification:
- `git status` — clean working tree.
- `git log --oneline` — initial commit `70c0fce`.
- `python -m unittest discover -s tests -v` — original 7 tests passed.

After Report 1 implementation:
- `git diff --check` — completed.
- `python -m unittest discover -s tests -v` — 15 tests passed.
- `git status` — checked modified files.
- `git diff --stat` — reviewed change summary.

AI-assisted investigation and implementation sessions are exported in `session_logs/`.

### Report 4: India morning sales appear under the previous day

**Status:** Fixed; no commit created yet, as requested.

**Reproduction and root cause**

Order creation and payment receipt timestamps are stored as UTC ISO-8601 strings ending in `Z`. `db.utcnow()` returns an aware UTC datetime, `db.to_iso()` serializes it in UTC, and `Payments._apply_succeeded()` stores the serialized payment receipt time. The daily report filters `payments.received_at` with `>= start` and `< end`.

The report defaulted to UTC calendar-day bounds, even though the shop's business date is India local time. For example, `2025-03-09T20:00:00Z` is `2025-03-10 01:30` in India, but the prior implementation included it in the March 9 report. Also, the prior `day_bounds_utc()` added positive `utc_offset_minutes` to UTC midnight; converting a local midnight to UTC requires subtracting the east-of-UTC offset.

Before the fix, the new boundary regression failed: the March 9 report returned 310 cents across 3 orders instead of 10 cents from the payment before India midnight. The test data also covers payments at `18:29:59Z` and `18:30:00Z` around India midnight, the UTC-previous-date/India-current-date case, and the next India midnight.

**Fix and design**

- Daily sales now defaults to India's UTC+5:30 business offset, derived from the report's stated shop location.
- Each local date's midnight and the following date's midnight are constructed as timezone-aware local datetimes and converted independently to UTC. The SQL keeps the half-open interval (`>= start`, `< end`), so the exact midnight belongs only to the new local day.
- The existing `utc_offset_minutes` override remains available and positive values mean minutes east of UTC. UTC storage and serialization are unchanged.
- The API and README now use/document the India default.

The current API accepts a numeric fixed offset, not a regional timezone identifier, so DST-observing zones are not supported by this interface. To support them later, accept an IANA timezone and resolve each local midnight with `zoneinfo.ZoneInfo`; do not reuse a single fixed offset or add 24 hours to a UTC boundary. India's UTC+5:30 offset does not observe DST.

**Tests and verification**

- Added a regression covering one instant immediately before and at India midnight, one timestamp on the previous UTC date but current India date, the last second of the India day, and the next midnight.
- Verified both the direct report function and the daily-report API default, plus the explicit `330`-minute override.
- Before the fix: the focused regression failed with the wrong day grouping.
- After the fix: the two focused daily-sales tests passed.
- Full suite: `python -m unittest discover -s tests -v` — 26 tests passed.
- Boundary check returned `2025-03-09T18:30:00Z` through (exclusive) `2025-03-10T18:30:00Z` for India March 10; explicit offset 0 still yields UTC midnight bounds.
- `git diff --check` completed without whitespace errors. Diff review showed Report 4 changes only in `tillpoint/reports.py`, `tillpoint/api.py`, `tests/test_orders.py`, this section, and the related README documentation. Reports 1–3 implementation was not changed.

**Commit**

Not committed, per instruction.

Proposed commit message: `Fix India daily sales date boundaries`

### Report 5: Concurrent checkouts oversell stock

**Status:** Fixed; not committed.

**Reproduction and root cause**

`Orders.create()` first expires pending orders, then starts `BEGIN IMMEDIATE`, loads/prices the items, reserves each item, writes the order, and commits. Exceptions during reservation or order creation roll the transaction back. `Catalog.get_product()` caches product rows in a per-instance dictionary, and each server worker has its own `Catalog` and SQLite connection.

Two independent connections to the same file were synchronized with a barrier after both had cached the last unit. Before the fix, both checkout requests returned HTTP 201, two orders were stored, and stock became `-1`.

The root cause was that `Catalog.reserve()` checked `product.stock` from that worker-local cache and then executed an unconditional `stock = stock - qty`. The second request began only after the first transaction committed, but its cache still said one unit was available. The database row was current; the precondition check was not.

`db.connect()` uses `isolation_level=None`, enables foreign keys, and does not set an explicit busy timeout. The SQLite connection default observed here is 5 seconds (5000 ms). `BEGIN IMMEDIATE` serializes writers to the same database file by acquiring the write reservation before order processing; it prevents simultaneous writer transactions but cannot refresh an application-level cache. If a writer cannot acquire the lock before the timeout, SQLite raises `OperationalError`/`SQLITE_BUSY`. That is a transient database contention error, not an out-of-stock result; retry policy belongs at the request/service boundary. This change does not convert busy errors into stock conflicts.

**Fix and transaction behavior**

- `Catalog.reserve()` now performs one conditional SQL update: decrement only when the current database row has at least the requested quantity.
- If that update affects no row, it queries the current stock; for an existing product with insufficient stock it raises `OutOfStock` with the actual available quantity. The existing API maps this to HTTP 409.
- `BEGIN IMMEDIATE` and the order transaction remain in place. The losing request's `OutOfStock` unwinds `Orders.create()` and rolls back any earlier item reservations in that order.
- A `CHECK (stock >= 0)` would be useful defense-in-depth, but adding it to `CREATE TABLE IF NOT EXISTS` would not change already-created databases. Retrofitting it requires a schema migration; the conditional update prevents negative stock for this reservation flow on both existing and new databases without that migration.

SQLite permits only one writer at a time per database file. The connection's 5-second busy wait handles ordinary short contention; longer contention still fails visibly with `SQLITE_BUSY` rather than being misreported as an inventory conflict. This fix does not add an automatic transaction retry.

**Tests and verification**

- Added a deterministic concurrency regression using two threads, two independent connections, one shared SQLite file, and a barrier after both workers cache the one available unit. No sleep-based timing assumption is used. Before the fix, the regression observed two HTTP 201 responses; after it, exactly one request succeeds and the other receives HTTP 409 with `0 available`.
- The regression also verifies final stock is zero and exactly one order exists.
- Added a rollback regression proving an insufficient second item restores an earlier reservation and leaves no order row.
- Focused reservation tests after the fix: 3 passed.
- Repeated the barrier-synchronized concurrency regression 25 times: all 25 passed.
- Full suite: `python -m unittest discover -s tests -v` — 28 tests passed.
- `git diff --check` completed without whitespace errors.
- Final implementation diff is limited to `tillpoint/catalog.py` and `tests/test_orders.py`; Reports 1–4 changes were not modified. Existing untracked investigation logs were left untouched.

**Commit**

Not committed, as requested.

Proposed commit message: `Prevent concurrent stock overselling`

### Report 6: Separate successful payments for the same order

**Status:** No production fix is needed. Report 1's remaining-balance validation already prevents the reported second full payment from being recorded.

**Observed behavior and root cause**

Reproduced with a 1200-cent order and two distinct `payment.succeeded` events, each for 1200 cents. The first event returned HTTP 200 and marked the order `paid`. The second returned HTTP 409 with `payment of 1200 cents exceeds remaining balance 0`; the database contained only the first event, `paid_cents` remained 1200, and the order remained `paid`. This does not reproduce the report's claim that both full payments are silently recorded.

The handler uses event ID only for retry idempotency, so distinct IDs are separate events. It then computes the order's remaining balance under `BEGIN IMMEDIATE` and rejects an amount above it before insertion. There is no separate duplicate-charge identifier or payment-intent field in the current event contract.

**Chosen policy and fix**

Preserve Report 1's policies: identical event IDs are retries; distinct event IDs represent distinct payment events; partial payments are allowed; and no event may make recorded payments exceed the order total. Two distinct events for 500 and 700 cents on a 1200-cent order are both accepted and complete the order. The second full 1200-cent payment is rejected. Preventing that by rejecting every second event would break legitimate partial payments and contradict the established policy. No payment implementation or database changes were made.

Added a focused test for two full-amount events with different IDs. It verifies the second request's HTTP 409 response, the paid order status and balance, and that only one payment row is stored. The existing Report 1 tests continue to cover distinct-ID partial payments and status/balance transitions. The new test would have failed against the pre-Report 1 handler, which inserted successful events without checking the remaining balance.

**Verification and trade-offs**

The controlled API scenario and the new regression test confirm the same result. Focused policy tests passed: 4 tests, including the new second-full-payment case, existing distinct-ID partial completion, remaining-balance rejection, and overpayment rejection. The complete suite passed: 29 tests (`python -m unittest discover -s tests -v`). `git diff --check` passed.

An actual second successful charge at the payment provider is external money movement, which this application cannot reverse: there is no refund or reconciliation integration. The second event is surfaced as HTTP 409 and is not recorded as an order payment. Since the provider retries until it receives a 2xx, this rejected event may be retried and rejected again; that operational behavior is unchanged. If the reported symptom refers to duplicate provider-side charges rather than the application's payment total, reconciliation/refund handling is still needed. If distinct events have individual amounts within the outstanding balance, the application deliberately accepts them as valid partial payments because event IDs alone cannot establish that they are unintended duplicates.

**Commit**

Not committed, as requested.

Proposed commit message: `Document Report 6 duplicate payment findings`