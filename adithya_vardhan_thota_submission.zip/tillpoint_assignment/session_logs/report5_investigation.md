User: We are working on Report 5 of the Tillpoint engineering assessment.

Reported issue:
"Ever since we started running two server workers, we have sold more units of an item than we had, and its stock went negative."

Project context:

- Reports 1–4 are completed, committed and documented.
- Do not undo or modify their fixes.
- Work only on Report 5.
- Python + SQLite application.
- Relevant files include tillpoint/catalog.py, tillpoint/orders.py, tillpoint/db.py, tillpoint/api.py and tests/test_orders.py.
PHASE 1 — INVESTIGATION

1. Trace the complete stock deduction flow during order creation.
2. Inspect how transactions are started, committed and rolled back.
3. Determine whether stock availability checks and stock deductions happen atomically.
4. Investigate SQLite connection settings, busy timeout, transaction mode and isolation behavior.
5. Simulate two independent database connections attempting to purchase the final available units at the same time.
6. Reproduce overselling or negative stock with the current implementation.
7. Identify the exact root cause with code evidence.
8. Explain why the existing BEGIN IMMEDIATE or other locking mechanisms do or do not prevent this issue across separate workers.
PHASE 2 — DESIGN
Before implementation, explain:

- The smallest reliable fix.
- Whether conditional SQL stock updates are needed.
- How transactions should handle concurrent requests.
- How lock contention and SQLITE_BUSY should be handled.
- Whether a database constraint should prevent negative stock.
- Any SQLite limitations relevant to multiple workers.
PHASE 3 — IMPLEMENTATION

1. Add deterministic concurrency regression tests using separate SQLite connections to the same database file.
2. Ensure the test demonstrates the original failure or proves the relevant race condition.
3. Implement the minimal safe fix.
4. Ensure stock can never become negative.
5. Ensure one request succeeds and the competing request gets an appropriate out-of-stock or conflict error.
6. Ensure transactions roll back correctly after failed reservations.
7. Preserve Reports 1–4 behavior.
8. Avoid unrelated refactoring or dependencies.
PHASE 4 — VERIFICATION AND DOCUMENTATION

1. Run the concurrency regression tests.
2. Run the complete test suite.
3. Run git diff --check.
4. Review the exact changes.
5. Update NOTES.md Report 5 section with reproduction, root cause, fix, tests, verification, trade-offs and commit information.
6. Do not commit yet. Suggest a commit message.
IMPORTANT:

- Do not use sleeps or flaky timing assumptions as the only concurrency test.
- Do not claim concurrency safety merely because a test passed once.
- Do not weaken or remove existing transactions.
- Do not invent test results.
- If the current implementation already serializes writes correctly, explain that and investigate another root cause instead of making an unnecessary change.

Copilot: Read skill [python-fact-grounded-coding]()
Completed with input: {"skill":"python-fact-grounded-coding"}

I’ll trace the order flow and transaction setup first, then reproduce the competing reservation against a shared SQLite file before choosing a fix.

Read []()
Completed with input: {
  "path": "C:\\Users\\av748\\Downloads\\tillpoint_assignment-20261122T130948Z-1-001\\tillpoint_assignment\\tillpoint\\catalog.py"
}

Read []()
Completed with input: {
  "path": "C:\\Users\\av748\\Downloads\\tillpoint_assignment-20261122T130948Z-1-001\\tillpoint_assignment\\tillpoint\\orders.py"
}

Read []()
Completed with input: {
  "path": "C:\\Users\\av748\\Downloads\\tillpoint_assignment-20261122T130948Z-1-001\\tillpoint_assignment\\tillpoint\\db.py"
}

Read []()
Completed with input: {
  "path": "C:\\Users\\av748\\Downloads\\tillpoint_assignment-20261122T130948Z-1-001\\tillpoint_assignment\\tests\\test_orders.py"
}

Read []()
Completed with input: {
  "path": "C:\\Users\\av748\\Downloads\\tillpoint_assignment-20261122T130948Z-1-001\\tillpoint_assignment\\NOTES.md"
}

Read []()
Completed with input: {
  "path": "C:\\Users\\av748\\Downloads\\tillpoint_assignment-20261122T130948Z-1-001\\tillpoint_assignment\\session_logs\\report4_investigation.md"
}

Ran terminal command: git status --short; git --no-pager log -5 --oneline

"Read" failed
Completed with input: {
  "path": "C:\\Users\\av748\\Downloads\\tillpoint_assignment-20261122T130948Z-1-001\\tillpoint\\api.py"
}
Tool execution failed: Path does not exist

Search for `OutOfStock|timeout|busy_timeout|BEGIN IMMEDIATE|Catalog\(`

Ran terminal command: @'
import os, tempfile, threading
from tillpoint import db
from tillpoint.api import App

with tempfile.TemporaryDirectory() as directory:
    path = os.path.join(directory, 'stock.sqlite')
    setup = db.connect(path)
    setup.execute("INSERT INTO products (sku, name, price_cents, stock) VALUES ('ONE', 'One', 100, 1)")
    setup.close()
    start = threading.Barrier(2)
    outcomes = []
    lock = threading.Lock()
    def worker(name):
        conn = db.connect(path)
        app = App(conn)
        cached = app.catalog.get_product('ONE').stock
        start.wait()
        try:
            order = app.orders.create(name, [('ONE', 1)])
            result = ('success', order['id'])
        except Exception as exc:
            result = (type(exc).__name__, str(exc))
        with lock:
            outcomes.append((name, cached, result))
        conn.close()
    threads = [threading.Thread(target=worker, args=(f'worker-{i}',)) for i in range(2)]
    for thread in threads: thread.start()
    for thread in threads: thread.join()
    check = db.connect(path)
    print('independent connection outcomes:', outcomes)
    print('final stock:', check.execute("SELECT stock FROM products WHERE sku='ONE'").fetchone()['stock'])
    print('orders created:', check.execute("SELECT COUNT(*) AS n FROM orders").fetchone()['n'])
    check.close()
'@ | python -

The race is reproduced: both independent connections cached stock `1`, both orders committed, and the final stock was `-1`. The writer lock did serialize the transactions; the stale per-connection Catalog cache let the second serialized transaction approve a reservation without rereading stock. I’m checking the API’s error contract and schema before laying out the minimal fix.

Read []()
Completed with input: {
  "path": "C:\\Users\\av748\\Downloads\\tillpoint_assignment-20261122T130948Z-1-001\\tillpoint_assignment\\tillpoint\\api.py"
}

Read [](), lines 1 to 90
Completed with input: {
  "path": "C:\\Users\\av748\\Downloads\\tillpoint_assignment-20261122T130948Z-1-001\\tillpoint_assignment\\tillpoint\\db.py",
  "view_range": [
    1,
    90
  ]
}

Ran terminal command: git status --short; git --no-pager diff -- tillpoint\catalog.py tillpoint\orders.py tillpoint\db.py tests\test_orders.py NOTES.md; python -c "import sqlite3; c=sqlite3.connect(':memory:'); print('sqlite', sqlite3.sqlite_version, 'default_timeout_seconds', c.execute('PRAGMA busy_timeout').fetchone()[0] / 1000, 'isolation_level_default', repr(c.isolation_level))"

Design: keep `BEGIN IMMEDIATE`—it serializes SQLite writers—but do not use cached stock as authorization. Reserve with a single conditional `UPDATE ... WHERE stock >= qty`, then on zero affected rows read current stock and raise `OutOfStock` (the API already maps it to HTTP 409). The existing order transaction will roll back any earlier item reservations. Retain SQLite’s 5-second busy timeout; if contention exceeds it, surface `SQLITE_BUSY` as a transient database failure rather than misreporting stock. A `CHECK(stock >= 0)` would be useful defense-in-depth but needs a migration to cover existing databases; the conditional update directly protects this reservation path without rebuilding tables. I’ll add deterministic shared-file tests first.

Edit []()

Ran terminal command: python -m unittest -v tests.test_orders.OrderDeskTest.test_concurrent_orders_do_not_oversell_cached_stock tests.test_orders.OrderDeskTest.test_failed_reservation_rolls_back_earlier_items
Tool execution failed with exit code 1

Edit 

Ran terminal command: python -m unittest -v tests.test_orders.OrderDeskTest.test_concurrent_orders_do_not_oversell_cached_stock tests.test_orders.OrderDeskTest.test_failed_reservation_rolls_back_earlier_items tests.test_orders.OrderDeskTest.test_out_of_stock

The new barrier-synchronized test failed before the fix with two `201` responses, and now passes with one `201` and one `409`; the failed multi-item reservation test also confirms the earlier item rolls back. I’m running the full suite and checking the pending diff next.

Ran terminal command: python -m unittest discover -s tests -v

Ran terminal command: git diff --check; if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }; git status --short; git --no-pager diff --stat; git --no-pager diff -- tillpoint\catalog.py tests\test_orders.py

Read [](), lines 140 to 230
Completed with input: {
  "path": "C:\\Users\\av748\\Downloads\\tillpoint_assignment-20261122T130948Z-1-001\\tillpoint_assignment\\NOTES.md",
  "view_range": [
    140,
    230
  ]
}

Edit []()

Edit []()

All 28 tests pass, and the fix’s safety comes from the database-side stock predicate—not scheduling luck. I’m repeating the barrier-based regression and reviewing the documented and code diffs before wrapping up.

Ran terminal command: @'
import io
import unittest
from tests.test_orders import OrderDeskTest

for run in range(25):
    suite = unittest.TestSuite([OrderDeskTest('test_concurrent_orders_do_not_oversell_cached_stock')])
    result = unittest.TextTestRunner(stream=io.StringIO()).run(suite)
    if not result.wasSuccessful():
        raise SystemExit('concurrency regression failed on run {}'.format(run + 1))
print('concurrency regression passed 25/25 runs')
'@ | python -

Ran terminal command: git diff --check; if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }; git status --short; git --no-pager diff --stat; git --no-pager diff -- tillpoint\catalog.py tests\test_orders.py NOTES.md

Read [](), lines 200 to 290
Completed with input: {
  "path": "C:\\Users\\av748\\Downloads\\tillpoint_assignment-20261122T130948Z-1-001\\tillpoint_assignment\\NOTES.md",
  "view_range": [
    200,
    290
  ]
}

Edit []()

Ran terminal command: git diff --check; if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }; git status --short; git --no-pager diff --stat

## Report 5 complete — not committed

The cause was the per-worker Catalog cache: each worker could see one available unit even after the other worker had sold it. `BEGIN IMMEDIATE` did serialize writes, but it could not refresh that cached stock.

Reservations now use a conditional SQL update against the current database stock. When stock is insufficient, the order fails with HTTP 409; the existing transaction rolls back any earlier reservations in that order. SQLite’s 5-second busy timeout remains unchanged; a `SQLITE_BUSY` timeout is a database contention error, not an out-of-stock response.

The shared-file concurrency test failed before the fix with two successful orders and stock at `-1`. Afterward, **28 tests passed**, and the deterministic concurrency test passed **25/25** runs. `git diff --check` passed. A database constraint would add defense-in-depth, but retrofitting one requires a schema migration; the conditional update guards this reservation flow without that migration.

Updated [catalog.py](), [test_orders.py](), and [NOTES.md](). Reports 1–4 were not modified.

**Suggested commit message:** `Prevent concurrent stock overselling`